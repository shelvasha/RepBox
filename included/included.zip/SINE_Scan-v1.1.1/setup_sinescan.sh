#! /bin/bash

DIRECTORY=$(pwd)
MAKEBLASTDB=$(which makeblastdb)
BLASTN=$(which makeblastdb)
CDHIT=$(which cd-hit)
STRETCHER=$(which stretcher)
MUSCLE=$(which muscle)
BEDTOOLS=$(which bedtools)
SINEDATA=$(echo $DIRECTORY'/SINEBase/SineDatabase.fasta')
RNADATA=$(echo $DIRECTORY'/RNABase/RNAsbase.fasta')
SINEFINDER=$(echo $DIRECTORY'/SINE-FINDER.py')

perl SINE_Scan_Installer.pl -d $DIRECTORY -a $SINEFINDER -f $MAKEBLASTDB -b $BLASTN -M $MUSCLE -e $STRETCHER -c $CDHIT -S $SINEDATA -R $RNADATA -l $BEDTOOLS 